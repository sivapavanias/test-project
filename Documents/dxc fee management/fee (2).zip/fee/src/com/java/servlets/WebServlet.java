package com.java.servlets;

public @interface WebServlet {

	String value();

}
